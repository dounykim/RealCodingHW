package poker;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Evaluator {

    public String evaluate(Hand hand){
        if (hand.getTotalCount()!=5) {
            throw new NotFullHandException();
        }

        boolean isRoyalStraightFlush = true;
        List<Integer> royalRank = new ArrayList<Integer>();
        royalRank.add(1);
        royalRank.add(11);
        royalRank.add(12);
        royalRank.add(13);
        royalRank.add(10);



        List<Card> handList = hand.getHandList();

        for (Card card : handList){
            if (card.getSuit() !=Suit.SPADE){
                isRoyalStraightFlush = false;
                break;
            }
            if (royalRank.contains(card.getRank())){
                royalRank.remove(new Integer(card.getRank()));
            } else {
                isRoyalStraightFlush = false;
                break;
            }
        }

        public boolean isFourCard(List<Card> handList){
            ArrayList<Integer> tempt = new ArrayList<Integer>();
            int count = 0;
            for (Card each : handList)
                tempt.add(each.getRank());
            Collections.sort(tempt);
            int stand = tempt.get(1);
            for (int i=0; i<tempt.size(); i++){
                if (tempt.get(i)==stand)
                    count++;
            }
            return count ==4 ? true : false;
    }



        // check royal straight flush

        return null;
    }



}

