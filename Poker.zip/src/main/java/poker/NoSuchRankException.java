package poker;

public class NoSuchRankException extends RuntimeException {
}
