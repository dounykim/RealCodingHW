package poker;

public class NoMoreHandException extends RuntimeException {
}
