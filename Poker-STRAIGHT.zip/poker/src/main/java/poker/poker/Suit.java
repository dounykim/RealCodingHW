package poker.poker;

public enum  Suit {
    DIAMOND,
    SPADE,
    HEART,
    CLUB;
}
