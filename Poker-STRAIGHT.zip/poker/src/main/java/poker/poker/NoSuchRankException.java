package poker.poker;

public class NoSuchRankException extends RuntimeException {
}
