package poker;

public class NomoreCardException extends RuntimeException {
}
