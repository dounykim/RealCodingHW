package poker;

import sun.plugin2.main.server.HeartbeatThread;

public enum Suit {
    DIAMOND,
    SPADE,
    HEART,
    CLOVER;
}
