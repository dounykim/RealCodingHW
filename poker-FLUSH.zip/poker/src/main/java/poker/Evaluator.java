package poker;

public class Evaluator {
}
