package poker;

public class NoSearchRankException extends RuntimeException {
}
