package poker;

public class NotFullHandException extends RuntimeException {
}
