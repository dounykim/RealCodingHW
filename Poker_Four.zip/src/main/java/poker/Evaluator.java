package poker;

import java.util.ArrayList;
import java.util.List;


public class Evaluator {

    public String evaluate(Hand hand){
        if (hand.getTotalCount()!=5) {
            throw new NotFullHandException();
        }

        boolean isRoyalStraightFlush = true;

        List<Integer> royalRank = new ArrayList<Integer>();
        royalRank.add(1);
        royalRank.add(11);
        royalRank.add(12);
        royalRank.add(13);
        royalRank.add(10);



        List<Card> handList = hand.getHandList();

        for (Card card : handList) {
            if (card.getSuit() != Suit.SPADE) {
                isRoyalStraightFlush = false;
                break;
            }

            if (royalRank.contains(card.getRank())) {
                royalRank.remove(new Integer(card.getRank()));
            }
        }

        if (royalRank.size() == 0) {
            isRoyalStraightFlush = true;

        }
        if (isRoyalStraightFlush) {
            return "ROYAL_STRAIGHT_FLUSH";
        }

        // check royal straight flush

        boolean isFourOfKind = true;
        List<Integer> fourCards = new ArrayList<Integer>();
        fourCards.add(2);
        fourCards.add(2);
        fourCards.add(2);
        fourCards.add(2);
        fourCards.add(3);

        List<Card> handListFour = hand.getHandList();
        for (Card card : handListFour) {
            if (fourCards.contains(card.getRank())) {
                fourCards.remove(new Integer(card.getRank()));
            }
        }
        if (fourCards.size()!=0)
        {
            isFourOfKind = false;
        }
        if (isFourOfKind)
        {
            return "Four_of_a_Kind";
        }




        return null;
    }

}


