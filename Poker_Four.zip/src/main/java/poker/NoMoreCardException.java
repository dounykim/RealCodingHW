package poker;

public class NoMoreCardException extends RuntimeException {
}
